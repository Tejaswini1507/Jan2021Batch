import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day5',
  templateUrl: './day5.component.html',
  styleUrls: ['./day5.component.css']
})
export class Day5Component implements OnInit {
  numberToCheck;
  isHidden:boolean=true;
  isHidden1:boolean=true;
  constructor() { }

  ngOnInit() {
  }
  onUser(value){
    console.log(value);
  }
  onNumber(myNum){
    console.log(myNum);
    this.numberToCheck=myNum;
    console.log("numberToCheck: " +this.numberToCheck);
    this.isHidden=false;
    this.isHidden1=false;

  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day4',
  templateUrl: './day4.component.html',
  styleUrls: ['./day4.component.css']
})
export class Day4Component implements OnInit {
  name: any;
  
  constructor() { }

  ngOnInit() {

  }
  onClick(name) {
    if (name === 'admin') {
      console.log("valid user");
      alert("valid user");
    } else {
      console.log("invalid user");
      alert("invalid user");
    }

  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day6',
  templateUrl: './day6.component.html',
  styleUrls: ['./day6.component.css']
})
export class Day6Component implements OnInit {
  courses:any[]=['Mongodb','ExpressJs','Angular','NodeJs','MEAN Stack'];
  // object
  user={
    id:1,
    name:'lmn'
  }
  // array of object
  user1=[
    {
      id:1,
      name:'lmn'
    },
    {
      id:2,
      name:'poi'
    },
    {
      id:3,
      name:'bnm'
    }
  ]

  // ngSwitch
  mycolor:string="";

  // keyup and keydown event
  mycolor1:string;
  mycolor2:string;
  constructor() { }

  ngOnInit() {
    
  }
  onClick(){
    // console.log(value);
    // this.mycolor=value;
    // console.log("mycolor" +this.mycolor)
  }
  onKeyup(){
    this.mycolor1="red";
  }
  onKeyDown(){
    this.mycolor2="green";
  }
}

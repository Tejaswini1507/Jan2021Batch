import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day3',
  templateUrl: './day3.component.html',
  styleUrls: ['./day3.component.css']
})
export class Day3Component implements OnInit {
  // class binding
  error:string="ErrorClass";
  rating:number=1;
  isError:boolean=false;
  isStyle:boolean=true;
  myoBJ={
    "ErrorClass":this.isError,
    "SuccessClass":!this.isError,
    "myStyle":this.isStyle
  }

  // style binding
  myColor:string="blue";
  myObj1={
    "color":"blue",
    "fontStyle":"italic"
  }

  // event and style binding
  mycolor1:string;
  mycolor2:string;;
  constructor() { }

  ngOnInit() {
  }
  onKeyup(){
    this.mycolor1="blue";
  }
  onKeyDown(){
    this.mycolor2="black";
  }
  onMouseOver(){
    this.mycolor1="blueviolet";
  }
  onMouseOut(){
    this.mycolor1="black";
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
  data:string="Angular Tutorial";
  data1:string="property binding";
  name:string="Angular";
  isHidden:boolean=false;
  myEvent:string="";

  constructor() { }

  ngOnInit() {
  }
  onClick(){
    console.log("Event Binding Works!");
    this.myEvent="Event Binding Works!";
  }

}
